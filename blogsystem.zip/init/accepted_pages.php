<?php
$accepted_list = array(
    'file',
    'rubriki',
    'registratsija',
    'dobavitj-statju',
    'main',
    'install',
    'test',
    'spisok',
    'avtorizatsija'
);
?>
