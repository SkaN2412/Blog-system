<?php
var_dump(Articles::get());
?>